/*Newsletter in home page*/
document.addEventListener("DOMContentLoaded", () => {
  const form = document.querySelector("#newsletter form");
  const emailInput = form.querySelector('input[type="email"]');

  function showMessage(message, isError = false) {
    let msgDiv = document.querySelector("#newsletter-message");
    if (!msgDiv) {
      msgDiv = document.createElement("div");
      msgDiv.id = "newsletter-message";
      msgDiv.style.marginTop = "10px";
      form.appendChild(msgDiv);
    }
    msgDiv.textContent = message;
    msgDiv.style.color = isError ? "salmon" : "lightgreen";
  }

  form.addEventListener("submit", (e) => {
    e.preventDefault();

    const email = emailInput.value.trim();

    if (!email) {
      showMessage("Email cannot be empty.", true);
      return;
    }

    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
      showMessage("Please enter a valid email address.", true);
      return;
    }

    showMessage("Thank you for subscribing!");
    form.reset();
  });
});


/*add a song section*/
// songForm.addEventListener("submit", (e) => {
//   e.preventDefault();
//   const formData = new FormData(songForm);
//   const song = Object.fromEntries(formData.entries());

//   // Get existing songs or initialize
//   const songs = JSON.parse(localStorage.getItem("myLibrary")) || [];
//   songs.push(song);
//   localStorage.setItem("myLibrary", JSON.stringify(songs));

//   formMsg.textContent = `Added: ${song.title} by ${song.artist}`;
//   formMsg.style.color = "lightgreen";
//   songForm.reset();
// });


const apiForm = document.getElementById("api-form");
const apiResults = document.getElementById("api-results");

// Handle API Search form submission
apiForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  const query = document.getElementById("search-query").value.trim();
  if (!query) {
    apiResults.innerHTML = "<p>Please enter a song title or artist name.</p>";
    return;
  }

  apiResults.innerHTML = "<p>Loading artist info...</p>";

  try {
    // Fetch artist info from TheAudioDB
    const res = await fetch(`https://theaudiodb.com/api/v1/json/2/search.php?s=${encodeURIComponent(query)}`);
    const data = await res.json();

    if (data.artists && data.artists.length > 0) {
      const artist = data.artists[0];
      apiResults.innerHTML = `
        <h3>${artist.strArtist}</h3>
        <img src="${artist.strArtistThumb || ''}" alt="Artist Image" style="max-width:200px; border-radius:8px; margin-bottom:15px;" />
        <p>${artist.strBiographyEN ? artist.strBiographyEN.substring(0, 500) + (artist.strBiographyEN.length > 500 ? '...' : '') : 'No biography available.'}</p>
        <p><a href="${artist.strWebsite ? 'https://' + artist.strWebsite : '#'}" target="_blank" rel="noopener noreferrer">Official Website</a></p>
      `;
    } else {
      apiResults.innerHTML = "<p>No artist info found. Try another artist name.</p>";
    }
  } catch (error) {
    console.error(error);
    apiResults.innerHTML = "<p>Error fetching artist info. Please try again later.</p>";
  }
});


const addSongForm = document.getElementById("add-song-form");
const formMessage = document.getElementById("form-message");

addSongForm.addEventListener("submit", (e) => {
  e.preventDefault();

  const formData = new FormData(addSongForm);
  const song = Object.fromEntries(formData.entries());

  // Convert "favorite" checkbox to boolean
  song.favorite = formData.get("favorite") === "on";

  // Save song to localStorage
  const songs = JSON.parse(localStorage.getItem("myLibrary")) || [];
  songs.push(song);
  localStorage.setItem("myLibrary", JSON.stringify(songs));

  formMessage.textContent = `Added: "${song.title}" by ${song.artist}`;
  formMessage.style.color = "lightgreen";
  addSongForm.reset();
});

