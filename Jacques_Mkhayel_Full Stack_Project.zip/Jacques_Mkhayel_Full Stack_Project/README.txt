# My Music Journal 

## Author
Jacques Mkhayel

## API Used
- [TheAudioDB API](https://www.theaudiodb.com/api_guide.php) — Used to fetch artist information including biography of artists. 

## Project Description
My Music Journal is a web application designed for music lovers to add their favorite songs along with detailed information such as title, artist, album, genre, rating, and notes. The "Add Song" page allows users to input this data, and also includes an API integration section where users can search for artist information to enrich their music entries.

## Custom Requirement Explanation
I was assigned to create a hero section with overlay text and a call-to-action button on the main page. This hero section serves as an engaging introduction to the application, featuring background imagery with a semi-transparent overlay to ensure text readability, accompanied by a clear call-to-action that encourages users to explore the app or add songs.
