const libraryContainer = document.getElementById("library-container");

function displaySongs() {
  const songs = JSON.parse(localStorage.getItem("myLibrary")) || [];

  if (songs.length === 0) {
    libraryContainer.innerHTML = "<p style='color:#ccc; text-align:center;'>No songs in your library yet.</p>";
    return;
  }

  libraryContainer.innerHTML = songs.map(song => {
    // Create stars for rating
    const stars = "★".repeat(Number(song.rating)) + "☆".repeat(5 - Number(song.rating));

    return `
      <div class="music-entry-card">
        <h3>${song.title}</h3>
        <p><strong>Artist:</strong> ${song.artist}</p>
        ${song.album ? `<p><strong>Album:</strong> ${song.album}</p>` : ""}
        ${song.genre ? `<p><strong>Genre:</strong> ${song.genre}</p>` : ""}
        ${song.year ? `<p><strong>Year:</strong> ${song.year}</p>` : ""}
        <div class="rating">${stars}</div>
        ${song.notes ? `<p class="review">${song.notes}</p>` : ""}
        ${song.favorite ? `<p style="color:#1db954;">★ Favorite</p>` : ""}
        ${song.cover ? `<img src="${song.cover}" alt="Cover Art" style="max-width:100%; border-radius:8px; margin-top:10px;">` : ""}
      </div>
    `;
  }).join("");
}

displaySongs();
